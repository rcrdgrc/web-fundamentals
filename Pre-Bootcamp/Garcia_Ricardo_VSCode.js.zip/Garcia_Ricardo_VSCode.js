console.log("I got a rainbow!")
onsole.log("And an extension called Eslint")