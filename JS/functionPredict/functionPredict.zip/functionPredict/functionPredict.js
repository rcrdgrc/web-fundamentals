function greeting(){
    return "Hello";
    console.log("World");
}
var word = greeting();
console.log(word);

//prints out Hello

function add(num1, num2){
    console.log("Summing Numbers!");
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);
    var sum = num1 + num2;
    return sum;
}
var result1 = add(3,5);
var result2 = add(4,7);
console.log(result1);
console.log(result2);

// print out summing number then num1 then num2 then sum by itself

function highFive(num){
    for(var i=0; i<num; i++){
        if(i == 5){
            console.log("High Five!");
        }
        else{
            console.log(i);
        }
    }
}

//when called it will consolde High Five if num is 5 else just the num from 0 to whatever num entered in the funct